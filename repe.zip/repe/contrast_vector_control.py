from transformers.modeling_outputs import BaseModelOutputWithPast, CausalLMOutputWithPast

from transformers.models.llama.modeling_llama import LlamaModel, LlamaForCausalLM
from transformers.cache_utils import StaticCache, DynamicCache, Cache
from transformers.models.mistral.modeling_mistral import MistralModel, MistralForCausalLM
from transformers.generation.stopping_criteria import StoppingCriteria, StoppingCriteriaList, validate_stopping_criteria
from transformers.generation.logits_process import LogitsProcessorList
from transformers.generation import GreedySearchDecoderOnlyOutput
from transformers import AutoTokenizer, AutoConfig, pipeline, AutoModelForCausalLM
from transformers.generation.streamers import BaseStreamer
import torch
import torch.nn.functional as F
from torch import nn
from typing import List, Optional, Tuple, Union
from transformers.modeling_attn_mask_utils import (
    AttentionMaskConverter,
    _prepare_4d_attention_mask,
    _prepare_4d_causal_attention_mask,
    _prepare_4d_causal_attention_mask_for_sdpa,
)
from functools import partial
import warnings
import logger
import numpy as np
import torch.distributed as dist


def _always_true(self, *args, **kwargs):
    return True

def contrast_greedy_search(
    self,
    input_ids: torch.LongTensor,
    logits_processor: Optional[LogitsProcessorList] = None,
    stopping_criteria: Optional[StoppingCriteriaList] = None,
    max_length: Optional[int] = None,
    pad_token_id: Optional[int] = None,
    eos_token_id: Optional[Union[int, List[int]]] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    output_scores: Optional[bool] = None,
    return_dict_in_generate: Optional[bool] = None,
    synced_gpus: bool = False,
    streamer: Optional["BaseStreamer"] = None,
    **model_kwargs,
    ) -> Union[GreedySearchDecoderOnlyOutput, torch.LongTensor]:

    alpha = model_kwargs.pop('alpha', None)
    contrast_tokens = model_kwargs.pop('contrast_tokens', None)
    compute_contrast = model_kwargs.pop('compute_contrast', None)
    pos_input_ids = model_kwargs.pop('pos_input_ids', None)
    pos_attention_mask = model_kwargs.pop('pos_attention_mask', None)
    neg_input_ids = model_kwargs.pop('neg_input_ids', None)
    neg_attention_mask = model_kwargs.pop('neg_attention_mask', None)
    control_layer_ids = model_kwargs.pop('control_layer_ids', None)

    assert not compute_contrast or not model_kwargs.get('use_cache', False), "Contrast Greedy Search not yet support generate with use_cache, please set model.generate(**kwargs, use_cache=False)"

    logits_processor = logits_processor if logits_processor is not None else LogitsProcessorList()
    stopping_criteria = stopping_criteria if stopping_criteria is not None else StoppingCriteriaList()
    
    if max_length is not None:
        warnings.warn(
            "`max_length` is deprecated in this function, use"
            " `stopping_criteria=StoppingCriteriaList([MaxLengthCriteria(max_length=max_length)])` instead.",
            UserWarning,
        )
        stopping_criteria = validate_stopping_criteria(stopping_criteria, max_length)

    pad_token_id = pad_token_id if pad_token_id is not None else self.generation_config.pad_token_id
    eos_token_id = eos_token_id if eos_token_id is not None else self.generation_config.eos_token_id

    if isinstance(eos_token_id, int):
        eos_token_id = [eos_token_id]
    
    eos_token_id_tensor = torch.tensor(eos_token_id).to(input_ids.device) if eos_token_id is not None else None
    output_scores = output_scores if output_scores is not None else self.generation_config.output_scores
    output_attentions = (
        output_attentions if output_attentions is not None else self.generation_config.output_attentions
    )

    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.generation_config.output_hidden_states
    )

    return_dict_in_generate = (
        return_dict_in_generate
        if return_dict_in_generate is not None
        else self.generation_config.return_dict_in_generate
    )

    # init attention / hidden states / scores tuples
    scores = () if (return_dict_in_generate and output_scores) else None
    decoder_attentions = () if (return_dict_in_generate and output_attentions) else None
    cross_attentions = () if (return_dict_in_generate and output_attentions) else None
    decoder_hidden_states = () if (return_dict_in_generate and output_hidden_states) else None

    # keep track of which sequences are already finished
    unfinished_sequences = torch.ones(input_ids.shape[0], dtype=torch.long, device=input_ids.device)

    this_peer_finished = False  # used by synced_gpus only
    while True:
        if synced_gpus:
            # Under synced_gpus the `forward` call must continue until all gpus complete their sequence.
            # The following logic allows an early break if all peers finished generating their sequence
            this_peer_finished_flag = torch.tensor(0.0 if this_peer_finished else 1.0).to(input_ids.device)
            # send 0.0 if we finished, 1.0 otherwise
            dist.all_reduce(this_peer_finished_flag, op=dist.ReduceOp.SUM)
            # did all peers finish? the reduced sum will be 0.0 then
            if this_peer_finished_flag.item() == 0.0:
                break

        model_inputs = self.prepare_inputs_for_generation(input_ids, **model_kwargs)

        outputs = self(
            **model_inputs,
            return_dict=True,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            pos_input_ids=pos_input_ids,
            pos_attention_mask=pos_attention_mask,
            neg_input_ids=neg_input_ids,
            neg_attention_mask=neg_attention_mask,
            contrast_tokens=contrast_tokens,
            compute_contrast=compute_contrast,
            alpha=alpha,
            control_layer_ids=control_layer_ids,
        )

        if synced_gpus and this_peer_finished:
            continue  # don't waste resources running the code we don't need

        next_token_logits = outputs.logits[:, -1, :]

        next_tokens_scores = logits_processor(input_ids, next_token_logits)

        # Store scores, attentions and hidden_states when required
        if return_dict_in_generate:
            if output_scores:
                scores += (next_tokens_scores,)
            if output_attentions:
                decoder_attentions += (
                    (outputs.attentions,)
                )

            if output_hidden_states:
                decoder_hidden_states += (
                    (outputs.hidden_states,)
                )


        next_tokens = torch.argmax(next_tokens_scores, dim=-1)

        if eos_token_id is not None:
            if pad_token_id is None:
                raise ValueError("If `eos_token_id` is defined, make sure that `pad_token_id` is defined.")
            next_tokens = next_tokens * unfinished_sequences + pad_token_id * (1 - unfinished_sequences)

        # update generated ids, model inputs, and length for next step
        input_ids = torch.cat([input_ids, next_tokens[:, None]], dim=-1)
        if streamer is not None:
            streamer.put(next_tokens.cpu())
        model_kwargs = self._update_model_kwargs_for_generation(
            outputs, model_kwargs
        )

        if eos_token_id_tensor is not None:
            unfinished_sequences = unfinished_sequences.mul(
                next_tokens.tile(eos_token_id_tensor.shape[0], 1).ne(eos_token_id_tensor.unsqueeze(1)).prod(dim=0)
            )

            # stop when each sentence is finished
            if unfinished_sequences.max() == 0:
                this_peer_finished = True

        # stop if we exceed the maximum length
        if stopping_criteria(input_ids, scores):
            this_peer_finished = True

        if this_peer_finished and not synced_gpus:
            break

    if streamer is not None:
            streamer.end()

    if return_dict_in_generate:
        return GreedySearchDecoderOnlyOutput(
            sequences=input_ids,
            scores=scores,
            attentions=decoder_attentions,
            hidden_states=decoder_hidden_states,
            past_key_values=model_kwargs.get("past_key_values"),
        )
    else:
        return input_ids
    


def forward_contrast_vector(self,
                            input_ids: torch.LongTensor=None,
                            attention_mask: Optional[torch.LongTensor] = None,
                            position_ids: Optional[torch.LongTensor] = None,
                            past_key_values: Optional[List[torch.FloatTensor]] = None,
                            inputs_embeds: Optional[torch.FloatTensor] = None,
                            use_cache: Optional[bool] = None,
                            output_attentions: Optional[bool] = None,
                            output_hidden_states: Optional[bool] = None,
                            return_dict: Optional[bool] = None,
                            cache_position: Optional[torch.FloatTensor] = None,
                            alpha: int = None,
                            contrast_tokens: int = None,
                            compute_contrast: bool = False,
                            pos_input_ids: torch.LongTensor = None,
                            pos_attention_mask: torch.LongTensor = None,
                            neg_input_ids: torch.LongTensor = None,
                            neg_attention_mask: torch.LongTensor = None,
                            control_layer_ids: List[int] = [],
                            pad_right: int=0
                          ) -> Union[Tuple, BaseModelOutputWithPast]:
  
    output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions

    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )

    use_cache = use_cache if use_cache is not None else self.config.use_cache
    return_dict = return_dict if return_dict is not None else self.config.use_return_dict

    #if (input_ids is None) ^ (inputs_embeds is not None):
    #    raise ValueError(
    #        "You cannot specify both input_ids and inputs_embeds at the same time, and must specify either one"
    #    )

    if input_ids is not None and inputs_embeds is not None:
        raise ValueError("You cannot specify both input_ids and inputs_embeds at the same time")
    elif input_ids is not None:
        batch_size, seq_length = input_ids.shape[:2]
    elif inputs_embeds is not None:
        batch_size, seq_length = inputs_embeds.shape[:2]
    else:
        raise ValueError("You have to specify either input_ids or inputs_embeds")

    if self.gradient_checkpointing and self.training and use_cache:
        logger.warning_once(
            "'use_cache=True' is incompatible with gradient checkpointing. Setting 'use_cache=False'."
        )
        use_cache = False
        
    if inputs_embeds is None:
        inputs_embeds = self.embed_tokens(input_ids)

    past_seen_tokens = 0

    if use_cache:
        if not isinstance(past_key_values, StaticCache):
            past_key_values = DynamicCache.from_legacy_cache(past_key_values)
            past_seen_tokens = past_key_values.get_seq_length()

    if position_ids is None:
        position_ids = torch.arange(past_seen_tokens + past_seen_tokens + inputs_embeds.shape[1], device=inputs_embeds.device).unsqueeze(0)

    attention_mask = _prepare_4d_causal_attention_mask_for_sdpa(attention_mask, (batch_size, seq_length), inputs_embeds, past_seen_tokens)

    #attention_mask = attention_mask if (attention_mask is not None and 0 in attention_mask) else None

    hidden_states = inputs_embeds

    all_hidden_states = () if output_hidden_states else None
    all_self_attns = () if output_attentions else None
    next_decoder_cache = None

    activations = None
    if compute_contrast:
        embeds_p = self.embed_tokens(pos_input_ids)
        embeds_n = self.embed_tokens(neg_input_ids)
        hidden_states_p, hidden_states_n = embeds_p, embeds_n
        
        pos_attention_mask = _prepare_4d_causal_attention_mask_for_sdpa(pos_attention_mask, embeds_p.shape[:2], embeds_p, past_seen_tokens)
        neg_attention_mask = _prepare_4d_causal_attention_mask_for_sdpa(neg_attention_mask, embeds_n.shape[:2], embeds_n, past_seen_tokens)
        pos_position_ids = torch.arange(past_seen_tokens + past_seen_tokens + hidden_states_p.shape[1], device=hidden_states_p.device).unsqueeze(0)
        neg_position_ids = torch.arange(past_seen_tokens + past_seen_tokens + hidden_states_n.shape[1], device=hidden_states_n.device).unsqueeze(0)

    for layer_id, decoder_layer in enumerate(self.layers):
        if output_hidden_states:
            all_hidden_states += (hidden_states,)

        if self.gradient_checkpointing and self.training:
            forward_function = partial(self._gradient_checkpointing_func, decoder_layer.__call__)

        else:
          forward_function = decoder_layer

        layer_outputs = forward_function(
            hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_values,
            output_attentions=output_attentions,
            use_cache=use_cache
        )

        hidden_states = layer_outputs[0]
        
        if compute_contrast:
    
            with torch.no_grad():
                hidden_states_p = forward_function(
                    hidden_states_p,
                    attention_mask=pos_attention_mask,
                    position_ids=pos_position_ids,
                    use_cache=use_cache
                )[0].detach()

                hidden_states_n = forward_function(
                    hidden_states_n,
                    attention_mask=neg_attention_mask,
                    position_ids=neg_position_ids,
                    use_cache=use_cache
                )[0].detach()
                
            if layer_id in control_layer_ids:
                activations = alpha * (hidden_states_p[:, contrast_tokens:] - hidden_states_n[:, contrast_tokens:])
                c_length = activations.shape[1]

                hidden_states[:, -c_length:, :] += activations
                hidden_states_p[:, -c_length:, :] += activations
                hidden_states_n[:, -c_length:, :] += activations

        if use_cache:
            next_decoder_cache = layer_outputs[2 if output_attentions else 1]
        
        if output_attentions:
            all_self_attns += (layer_outputs[1],)

    hidden_states = self.norm(hidden_states)

    if output_hidden_states:
        all_hidden_states += (hidden_states,)
    
    next_cache = None
    if use_cache:
        next_cache = (
            next_decoder_cache.to_legacy_cache() if isinstance(next_decoder_cache, Cache) else next_decoder_cache
        )
    if not return_dict:
        return tuple(v for v in [hidden_states, next_cache, all_hidden_states, all_self_attns] if v is not None)

    return BaseModelOutputWithPast(
        last_hidden_state=hidden_states,
        past_key_values=next_cache,
        hidden_states=all_hidden_states,
        attentions=all_self_attns
    )

class ContrastVecLlamaForCausalLM(LlamaForCausalLM):
    def __init__(self, config):
        nn.Module.__init__(self)
        self.config = config
        self.model = LlamaModel(config)
        self.vocab_size = config.vocab_size
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        # Initialize weights and apply final processing
        self.post_init()

        # override current forward and generation functions
        self.model.forward = partial(forward_contrast_vector, self.model)
        self.greedy_search = partial(contrast_greedy_search, self)
        # turn off _validate_model_kwargs, TODO: implement _validate_model_kwargs
        self._validate_model_kwargs = partial(_always_true, self)

    def forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        #cache_position: Optional[torch.LongTensor] = None,
        **kwargs
    ) -> Union[Tuple, CausalLMOutputWithPast]:

        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            **kwargs
        )


        hidden_states = outputs[0]
        if self.config.pretraining_tp > 1:
            lm_head_slices = self.lm_head.weight.contrast_tokens(self.vocab_size // self.config.pretraining_tp, dim=0)
            logits = [F.linear(hidden_states, lm_head_slices[i]) for i in range(self.config.pretraining_tp)]
            logits = torch.cat(logits, dim=-1)
        else:
            logits = self.lm_head(hidden_states)
        logits = logits.float()

        loss = None
        if labels is not None:
            # Shift so that tokens < n predict n
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            # Flatten the tokens
            loss_fct = nn.CrossEntropyLoss()
            shift_logits = shift_logits.view(-1, self.config.vocab_size)
            shift_labels = shift_labels.view(-1)
            # Enable model parallelism
            shift_labels = shift_labels.to(shift_logits.device)
            loss = loss_fct(shift_logits, shift_labels)

        if not return_dict:
            output = (logits,) + outputs[1:]
            return (loss,) + output if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )
